VALIDO - PDF Validation & Data Extraction Tool

INSTALLATION:
1. Run Valido-Setup.exe
2. If Windows shows a security warning, click "More info" → "Run anyway"
3. Follow the installation wizard
4. Launch Valido from Desktop or Start Menu

That's it! The security warning is normal for new software.

