VALIDO - PDF Validation & Data Extraction Tool

INSTALLATION:
1. Run Valido-Setup.exe
2. If Windows shows a security warning, click "More info" → "Run anyway"
   (Standard for new software - safe to proceed)
3. Follow the installation wizard
4. Launch Valido from Desktop or Start Menu

SUPPORT:
Website: https://validoapp.com
Feedback: Use the Feedback button in the app

© 2024 Valido
